#include <mem/palloc.h>
#include <bitmap.h>
#include <type.h>
#include <round.h>
#include <mem/mm.h>
#include <synch.h>
#include <device/console.h>
#include <mem/paging.h>
#include<mem/swap.h>

/* Page allocator.  Hands out memory in page-size (or
   page-multiple) chunks.  
   */
/* pool for memory */

struct memory_pool
{
	struct lock lock;                   
	struct bitmap *bitmap; 
	uint32_t *addr;                    
};
/* kernel heap page struct */
struct khpage{
	uint16_t page_type;
	uint16_t nalloc;
	uint32_t used_bit[4];
	struct khpage *next;
};

/* free list */
struct freelist{
	struct khpage *list;
	int nfree;
};

struct memory_pool kernel_pool;
struct memory_pool user_pool;

static struct khpage *khpage_list;
static struct freelist freelist;
static uint32_t page_alloc_index;

/* Initializes the page allocator. */
//
	void
init_palloc (void) 
{
	/* Calculate the space needed for the khpage list */
	//size_t bm_size = sizeof(struct khpage) * 1024;

	/* khpage list alloc */
	//khpage_list = (struct khpage *)(KERNEL_ADDR);

	/* initialize */
	/*memset((void*)khpage_list, 0, bm_size);
	page_alloc_index = 0;
	freelist.list = NULL;
	freelist.nfree = 0;*/

	size_t kernel_cnt = (size_t)(USER_POOL_START - KERNEL_ADDR)/PAGE_SIZE;
	size_t user_cnt = (size_t)(RKERNEL_HEAP_START - USER_POOL_START)/PAGE_SIZE;

	kernel_pool.bitmap = create_bitmap(kernel_cnt, (void *)KERNEL_ADDR, 0);
	user_pool.bitmap = create_bitmap(user_cnt, (void *)USER_POOL_START, 0);

	kernel_pool.addr = (uint32_t *)(KERNEL_ADDR + 0x1000);
	user_pool.addr = (uint32_t *)(USER_POOL_START + 0x1000);
}



/* Obtains and returns a group of PAGE_CNT contiguous free pages.
   */
	void *
palloc_get_multiple_page (enum palloc_flags flags, size_t page_cnt)
{
	void *pages = NULL;
	size_t index;
	//struct khpage *khpage = freelist.list;
	//struct khpage *prepage = freelist.list;
	size_t page_idx;

	if (page_cnt == 0)
		return NULL;

	/*while(khpage != NULL){
		if(khpage->nalloc == page_cnt){
			page_idx = ((uint32_t)khpage - (uint32_t)khpage_list)/sizeof(struct khpage);
			pages = (void*)(VKERNEL_HEAP_START + page_idx * PAGE_SIZE);

			if(prepage == khpage){
				freelist.list = khpage->next;
				freelist.nfree--;
				break;
			}else{
				prepage->next = khpage->next;
				freelist.nfree--;
				break;
			}
				   	
		}
		prepage = khpage;
		khpage = khpage->next;
	}*/

	if(flags == user_area) {
			index = find_bitmap(user_pool.bitmap, 0, page_cnt, 0);

			if(index == BITMAP_ERROR){
				printk("no space\n");
				return NULL;
			}
			/*for(int i=1; i<page_cnt; i++) {
				cont &= test_bitmap(user_pool.bitmap, index+i);
			}*/

			set_multi_bitmap (user_pool.bitmap, index, page_cnt, true);
			pages = (void*)(user_pool.addr) + index * PAGE_SIZE;
			memset(pages, 0, page_cnt * PAGE_SIZE);
	}

	else if(flags == kernel_area) {
			index = find_bitmap(kernel_pool.bitmap, 0, page_cnt, 0);

			if(index == BITMAP_ERROR){
				printk("no space\n");
				return NULL;
			}

			set_multi_bitmap (kernel_pool.bitmap, index, page_cnt, true);
			pages = (void*)(kernel_pool.addr) + index * PAGE_SIZE;
			memset(pages, 0, page_cnt * PAGE_SIZE);

	}

	return (void *)pages; 
}

/* Obtains a single free page and returns its address.
   */
	uint32_t *
palloc_get_one_page (enum palloc_flags flags) 
{
	return palloc_get_multiple_page (flags, 1);
}

/* Frees the PAGE_CNT pages starting at PAGES. */
	void
palloc_free_multiple_page (void *pages, size_t page_cnt) 
{
	/*struct khpage *khpage = freelist.list;
	size_t page_idx = (((uint32_t)pages - VKERNEL_HEAP_START) / PAGE_SIZE);

	if (pages == NULL || page_cnt == 0)
		return;

	if(khpage == NULL){
		freelist.list = khpage_list + page_idx;
		freelist.list->nalloc = page_cnt;
		freelist.list->next = NULL;
	}
	else{

		while(khpage->next != NULL){
			khpage = khpage->next;
		}

		khpage->next = khpage_list + page_idx;
		khpage->next->nalloc = page_cnt;
		khpage->next->next = NULL;
	}

	freelist.nfree++;
	 */


	if((pages >= (void *)(KERNEL_ADDR)) && (pages < (void *)(USER_POOL_START))){
		set_multi_bitmap (kernel_pool.bitmap, (pages-(void*)kernel_pool.addr)/PAGE_SIZE, page_cnt, false);
	}

	else if((pages >= (void *)USER_POOL_START) && (pages < (void *)RKERNEL_HEAP_START)){
		set_multi_bitmap (user_pool.bitmap, (pages-(void*)user_pool.addr)/PAGE_SIZE, page_cnt, false);
	}
}

/* Frees the page at PAGE. */
	void
palloc_free_one_page (void *page) 
{
	palloc_free_multiple_page (page, 1);
}


void palloc_pf_test(void)
{
	 uint32_t *one_page1 = palloc_get_one_page(user_area);
	 uint32_t *one_page2 = palloc_get_one_page(user_area);
	 uint32_t *two_page1 = palloc_get_multiple_page(user_area,2);
	 uint32_t *three_page;
	 printk("one_page1 = %x\n", one_page1); 
	 printk("one_page2 = %x\n", one_page2); 
	 printk("two_page1 = %x\n", two_page1);

	 printk("=----------------------------------=\n");
	 palloc_free_one_page(one_page1);
	 palloc_free_one_page(one_page2);
	 palloc_free_multiple_page(two_page1,2);

	 one_page1 = palloc_get_one_page(user_area);
	 one_page2 = palloc_get_one_page(user_area);
	 two_page1 = palloc_get_multiple_page(user_area,2);

	 printk("one_page1 = %x\n", one_page1);
	 printk("one_page2 = %x\n", one_page2);
	 printk("two_page1 = %x\n", two_page1);

	 printk("=----------------------------------=\n");
	 palloc_free_multiple_page(one_page2, 3);
	 one_page2 = palloc_get_one_page(user_area);
	 three_page = palloc_get_multiple_page(user_area,3);

	 printk("one_page1 = %x\n", one_page1);
	 printk("one_page2 = %x\n", one_page2);
	 printk("three_page = %x\n", three_page);

	 palloc_free_one_page(one_page1);
	 palloc_free_one_page(three_page);
	 three_page = (uint32_t*)((uint32_t)three_page + 0x1000);
	 palloc_free_one_page(three_page);
	 three_page = (uint32_t*)((uint32_t)three_page + 0x1000);
	 palloc_free_one_page(three_page);
	 palloc_free_one_page(one_page2);
}

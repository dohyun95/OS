#include <ssulib.h>

void delay(int times)
{
	int i;
	for(i = 0; i < times; i++)
	{
		int n = INT32_MAX/2;
		while(n-- > 0);
	}
}

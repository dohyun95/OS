#include <list.h>
#include <proc/sched.h>
#include <mem/malloc.h>
#include <proc/proc.h>
#include <proc/switch.h>
#include <interrupt.h>

extern struct list plist;
extern struct list rlist;
extern struct list runq[RQ_NQS];

extern struct process procs[PROC_NUM_MAX];
extern struct process *idle_process;
struct process *latest;

bool more_prio(const struct list_elem *a, const struct list_elem *b,void *aux);
int scheduling; 					// interrupt.c

struct process* get_next_proc(void) 
{
	bool found = false;
	struct process *next = NULL;
	struct list_elem *elem;

	/* 
	   You shoud modify this function...
	   Browse the 'runq' array 
	*/

	/*for(elem = list_begin(&rlist); elem != list_end(&rlist); elem = list_next(elem))
	{
		struct process *p = list_entry(elem, struct process, elem_stat);

		if(p->state == PROC_RUN)
			return p;
	}*/


	for(int i = 0; i < 25; i++) {
		if(!list_empty(&runq[i])) {
			for(elem = list_begin(&runq[i]); elem != list_end(&runq[i]); elem = list_next(elem))
			{
				struct process *p = list_entry(elem, struct process, elem_stat);

				if(p->state == PROC_RUN)
					return p;
			}	
		}
	}

	return next;
}

void schedule(void)
{

	struct process *cur;
	struct process *next;
	int cnt=0;

	/* You shoud modify this function.... */

	intr_disable();
	proc_wake();

	if(cur_process->pid != 0) {
		next = idle_process;
		cur = cur_process;
		cur_process = idle_process;

		switch_process(cur, next);
		intr_enable();
		return ;
	}

	struct list_elem *elem;
	for(elem = list_begin(&plist); elem != list_end(&plist); elem = list_next(elem))
	{
		struct process *p = list_entry(elem, struct process, elem_all);
		if((p->state == PROC_RUN) && (p->pid != 0)) {
			if(cnt > 0)
				printk(", ");
			printk("#= %d ", p->pid);
			printk("p= %d ", p->priority);
			printk("c= %d ", p->time_slice);
			printk("u= %d", p->time_used);
			cnt++;
		}
	}	

	next = get_next_proc();
	cur = cur_process;
	cur_process = next;
	cur_process->time_slice = 0;

	if(next->pid != 0) {
		printk("\n");
		printk("Selected # = %d\n", next->pid); 
	}

	switch_process(cur, next);

	intr_enable();
}
